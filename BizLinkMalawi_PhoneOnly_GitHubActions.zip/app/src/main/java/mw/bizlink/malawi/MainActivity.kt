package mw.bizlink.malawi

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Business(
    val name: String,
    val category: String,
    val location: String,
    val description: String,
    val phone: String? = null,
    val whatsapp: String? = null,
    val icon: String = "🏪"
)

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private val businesses = mutableListOf(
        Business(
            "Madalitso Traders", "Agricultural produce",
            "Kapyanga Trading Centre, Kasungu, T/A Wimbe",
            "All agricultural produces", "0996963141", "0888931336", "🌾"
        ),
        Business(
            "Nation Banda", "Piglets",
            "Chintchinda Primary School",
            "Piglets available", null, null, "🐖"
        ),
        Business(
            "Masauko Chimseu", "Vegetables",
            "Chipumba Village",
            "Different vegetables", "0980600474", "0888931343", "🥬"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFF4F7F6.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(22))
            setBackgroundColor(0xFF087F5B.toInt())
        }
        val title = TextView(this).apply {
            text = "🤝 BizLink Malawi"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val tag = TextView(this).apply {
            text = "Find businesses. Get customers. Grow together."
            textSize = 13f
            setTextColor(0xFFE8FFF6.toInt())
            setPadding(0, dp(5), 0, dp(12))
        }
        val search = EditText(this).apply {
            hint = "🔎 Search businesses, services or products..."
            setSingleLine(true)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        header.addView(title)
        header.addView(tag)
        header.addView(search)
        root.addView(header)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(90))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(7), 0, dp(7))
        }
        val home = navButton("🏠\nHome")
        val add = navButton("➕\nAdd Business")
        val account = navButton("👤\nAccount")
        nav.addView(home, LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(add, LinearLayout.LayoutParams(0, dp(58), 1f))
        nav.addView(account, LinearLayout.LayoutParams(0, dp(58), 1f))
        add.setOnClickListener { showAddBusiness() }
        account.setOnClickListener {
            Toast.makeText(this, "Business account will be added in the next version.", Toast.LENGTH_SHORT).show()
        }
        root.addView(nav)

        search.setOnEditorActionListener { _, _, _ ->
            renderBusinesses(search.text.toString())
            true
        }
        search.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_UP) {
                renderBusinesses(search.text.toString()); true
            } else false
        }

        setContentView(root)
        renderBusinesses("")
    }

    private fun navButton(text: String) = Button(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(0xFF087F5B.toInt())
        setBackgroundColor(0x00FFFFFF)
    }

    private fun renderBusinesses(query: String) {
        list.removeAllViews()
        val heading = TextView(this).apply {
            text = if (query.isBlank()) "Featured Businesses" else "Search Results"
            textSize = 20f
            setTextColor(0xFF17221E.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        }
        list.addView(heading)

        val q = query.trim().lowercase()
        val matches = businesses.filter {
            q.isBlank() || "${it.name} ${it.category} ${it.location} ${it.description}".lowercase().contains(q)
        }
        if (matches.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "No businesses found."
                textSize = 16f
                setPadding(0, dp(20), 0, 0)
            })
        } else {
            matches.forEach { addBusinessCard(it) }
        }
    }

    private fun addBusinessCard(b: Business) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            setBackgroundColor(0xFFFFFFFF.toInt())
            elevation = dp(3).toFloat()
        }
        val top = LinearLayout(this)
        val icon = TextView(this).apply { text = b.icon; textSize = 30f }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        info.addView(TextView(this).apply {
            text = b.name; textSize = 17f; setTextColor(0xFF17221E.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        info.addView(TextView(this).apply {
            text = "${b.category} • ${b.location}"; textSize = 12f; setTextColor(0xFF69746F.toInt())
        })
        info.addView(TextView(this).apply {
            text = b.description; textSize = 13f; setPadding(0,dp(4),0,0)
        })
        top.addView(icon)
        top.addView(info, LinearLayout.LayoutParams(0,-2,1f))
        card.addView(top)

        val buttons = LinearLayout(this).apply { setPadding(0, dp(12), 0, 0) }
        if (b.phone != null) {
            val call = Button(this).apply { text = "📞 Call"; setTextColor(0xFF087F5B.toInt()) }
            call.setOnClickListener {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${b.phone}")))
            }
            buttons.addView(call, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        if (b.whatsapp != null) {
            val wa = Button(this).apply { text = "💬 WhatsApp"; setTextColor(0xFF16833F.toInt()) }
            wa.setOnClickListener {
                val digits = b.whatsapp.filter { it.isDigit() }
                val intl = if (digits.startsWith("265")) digits else "265" + digits.trimStart('0')
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$intl")))
            }
            buttons.addView(wa, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        card.addView(buttons)
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, dp(6), 0, dp(6))
        list.addView(card, params)
    }

    private fun showAddBusiness() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            setBackgroundColor(0xFFF4F7F6.toInt())
        }
        val title = TextView(this).apply {
            text = "➕ Add Your Business"
            textSize = 24f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFF087F5B.toInt())
        }
        root.addView(title)
        val fields = mutableListOf<EditText>()
        fun field(hint: String): EditText {
            val e = EditText(this).apply { this.hint = hint; setSingleLine(false) }
            root.addView(e, LinearLayout.LayoutParams(-1, dp(58)))
            fields.add(e)
            return e
        }
        val name = field("Business name *")
        val category = field("Category (e.g. Farmers, Repairs, Shops) *")
        val phone = field("Phone number")
        val whatsapp = field("WhatsApp number")
        val location = field("Location *")
        val services = field("Products / Services")

        val save = Button(this).apply {
            text = "Save Business"
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xFF087F5B.toInt())
        }
        root.addView(save, LinearLayout.LayoutParams(-1, dp(56)))
        val back = Button(this).apply { text = "← Back to Home" }
        root.addView(back)
        save.setOnClickListener {
            if (name.text.toString().trim().isEmpty() || location.text.toString().trim().isEmpty()) {
                Toast.makeText(this, "Please enter the business name and location.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            businesses.add(
                Business(
                    name.text.toString().trim(),
                    category.text.toString().trim().ifEmpty { "Other" },
                    location.text.toString().trim(),
                    services.text.toString().trim().ifEmpty { "Products and services" },
                    phone.text.toString().trim().ifEmpty { null },
                    whatsapp.text.toString().trim().ifEmpty { null },
                    "🏪"
                )
            )
            Toast.makeText(this, "Business added successfully!", Toast.LENGTH_SHORT).show()
            showHome()
        }
        back.setOnClickListener { showHome() }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
