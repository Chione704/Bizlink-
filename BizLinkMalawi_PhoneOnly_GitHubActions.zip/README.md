# BizLink Malawi - Android Studio Project

This is the first native Android project for BizLink Malawi.

## What is included
- BizLink Malawi home screen
- Search businesses
- 3 real test listings supplied for the prototype:
  - Madalitso Traders
  - Nation Banda
  - Masauko Chimseu
- Call and WhatsApp buttons for the supplied contacts
- Add Business form
- New businesses appear in the current app session
- No external database yet

## Build the APK
1. Install Android Studio on a computer.
2. Open this project folder in Android Studio.
3. Let Gradle sync/download the Android dependencies.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will produce an APK you can install on an Android phone.

## Important
This version is an MVP. Business data is stored only while the app is running. The next major version should use an online database and user accounts so businesses remain available to everyone.

Application ID: mw.bizlink.malawi
Version: 1.0
