# BizLink Malawi — Phone-only APK build

This project includes `.github/workflows/build-apk.yml`.

Phone workflow:
1. Create/sign in to GitHub.
2. Create a new repository.
3. Upload all files in this project.
4. Open the repository's **Actions** tab.
5. Select **Build BizLink Malawi APK**.
6. Tap **Run workflow**.
7. When the workflow finishes, open the run and download the **BizLink-Malawi-APK** artifact.
8. Extract the downloaded artifact and install the APK on your Android phone.

The workflow builds a debug APK for testing. GitHub Actions runs the Gradle build on a hosted runner; no Android Studio is required on the phone.
